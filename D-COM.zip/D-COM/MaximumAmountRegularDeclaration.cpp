#include "MaximumAmountRegularDeclaration.h"
#include "ui_MaximumAmountRegularDeclaration.h"

#include "QDebug"

MaximumAmountRegularDeclaration::MaximumAmountRegularDeclaration(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MaximumAmountRegularDeclaration),
    currentPage(0),
    pageSize(3),
    totalRows(10),
    totalPages((totalRows + pageSize - 1) / pageSize)
{
    ui->setupUi(this);
    ui->widget_4->setVisible(true);
    QStringList headerLabels;
    headerLabels << "状态" << "机构代码" << "机构名称" << "净资本（百万元）" << "合计资产总额（百万元）"
                 << "最高额度（百万元）" << "控制类别" << "录入人" << "录入时间";
    ui->tableWidget_2->clear(); // 清空表格内容
    ui->tableWidget_2->setColumnCount(headerLabels.size());
    ui->tableWidget_2->setHorizontalHeaderLabels(headerLabels);
    ui->tableWidget_2->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget_2->setRowCount(pageSize);
    // 隐藏左侧的行号框
    updateTableDisplay();
    ui->tableWidget_2->verticalHeader()->setVisible(false);
    connect(ui->pushButton_9, &QPushButton::clicked, this, &MaximumAmountRegularDeclaration::previousPageButton_clicked);
    connect(ui->pushButton_10, &QPushButton::clicked, this, &MaximumAmountRegularDeclaration::nextPageButton_clicked);
    connect(ui->pushButton_17, &QPushButton::clicked, this, &MaximumAmountRegularDeclaration::goToImport);
}

MaximumAmountRegularDeclaration::~MaximumAmountRegularDeclaration()
{
    delete ui;
}

void MaximumAmountRegularDeclaration::updateTableDisplay()
{
    int startRow = currentPage * pageSize; // 当前页的起始行
    int endRow = qMin(startRow + pageSize, totalRows); // 当前页的结束行
    int numRows = endRow - startRow; // 当前页的行数

    ui->tableWidget_2->setRowCount(endRow - startRow);

    for (int row = startRow; row < endRow; ++row) {
        int rowIndex = row - startRow; // 当前页内的行索引

        QTableWidgetItem *item1 = new QTableWidgetItem("已录入");
        QTableWidgetItem *item2 = new QTableWidgetItem("00030");
        QTableWidgetItem *item3 = new QTableWidgetItem("长江证券股份有限公司" + QString::number(row));

        ui->tableWidget_2->setItem(rowIndex, 0, item1);
        ui->tableWidget_2->setItem(rowIndex, 1, item2);
        ui->tableWidget_2->setItem(rowIndex, 2, item3);
    }
    ui->lineEdit_6->setText("当前页记录数:" + QString::number(numRows));
    ui->lineEdit_10->setText("当前页码:" + QString::number(currentPage + 1) + "/" + QString::number(totalPages));
    ui->lineEdit_11->setText("共计:" + QString::number(totalRows) + "条记录");
}


void MaximumAmountRegularDeclaration::previousPageButton_clicked()
{
    if (currentPage > 0) {
        currentPage--;
        updateTableDisplay();
    }
}

void MaximumAmountRegularDeclaration::nextPageButton_clicked()
{
    if (currentPage < totalPages - 1) {
        currentPage++;
        updateTableDisplay();
    }
}

void MaximumAmountRegularDeclaration::goToImport()
{
    emit informationReturned();
}
