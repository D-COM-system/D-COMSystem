#include "ImportOfDeclarations.h"
#include "ui_ImportOfDeclarations.h"

#include "xlsxdocument.h"
#include "xlsxworksheet.h"

#include <QFile>
#include <QTextStream>

QString nowFilePath = "";

ImportOfDeclarations::ImportOfDeclarations(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ImportOfDeclarations)
{
    ui->setupUi(this);

    connect(ui->pushButton_19, &QPushButton::clicked, this, &ImportOfDeclarations::backToImport);
    connect(ui->pushButton_5, &QPushButton::clicked, this,&ImportOfDeclarations::chooseFile);
    connect(ui->pushButton_17, &QPushButton::clicked, this,&ImportOfDeclarations::importFile);
}

ImportOfDeclarations::~ImportOfDeclarations()
{
    delete ui;
}

void ImportOfDeclarations::backToImport()
{
    emit informationBack();
}

void  ImportOfDeclarations::chooseFile()
{
    QString filePath = QFileDialog::getOpenFileName(this, "Select File", "", "CSV Files (*.csv);;Excel Files (*.xlsx)");
    if (!filePath.isEmpty()) {
        qDebug() << "Selected File: " << filePath;
        // 这里可以处理所选文件的路径
    }
    QString nativePath = QDir::toNativeSeparators(filePath);

    // 将路径分割为各个部分
    QStringList pathParts = nativePath.split(QDir::separator(), QString::SkipEmptyParts);

    // 移除盘符（如Macintosh HD）
    if (pathParts.size() > 0) {
        pathParts.removeFirst();
    }

    // 按照指定格式拼接路径
    QString convertedPath = pathParts.join(" ▶ ");

    // 将路径分隔符转换回原生格式
    convertedPath = QDir::fromNativeSeparators(convertedPath);

    ui->lineEdit_6->setText(convertedPath);
    nowFilePath = filePath;
}

void ImportOfDeclarations::importFile()
{
//    QFile file(nowFilePath);
//    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
//        qDebug() << "Failed to open file:" << file.errorString();
//        return;
//    }

//    QString fileExtension = QFileInfo(nowFilePath).suffix().toLower();

//    if (fileExtension == "csv") {
//        QTextStream in(&file);
//        int rowCount = 0;
//        while (!in.atEnd()) {
//            in.readLine();
//            rowCount++;
//        }
//        qDebug() << "Number of rows: " << rowCount;
//    }
//    else if (fileExtension == "xlsx") {
//        QXlsx::Document xlsx(nowFilePath);
//        if (xlsx.load()) {
//            QXlsx::Worksheet* sheet = xlsx.currentWorksheet();
//            if (sheet) {
//                int rowCount = sheet->dimension().lastRow();
//                qDebug() << "Number of rows: " << rowCount;
//            }
//        }
//    }
//    else {
//        qDebug() << "Unsupported file format.";
//    }

//    file.close();
}
