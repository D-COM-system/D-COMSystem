// GlobalData.h
#ifndef GLOBALDATA_H
#define GLOBALDATA_H

#include <QString>

extern QString globalUserName;
extern QString globalCusNumber;


#endif // GLOBALDATA_H
