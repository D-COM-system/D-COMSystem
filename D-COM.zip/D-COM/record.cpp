#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>

void createRecord(QString dirPath)
{
    QString dbName = "database.db";
    QString dbPath = dirPath + "./" + dbName;  // Use a relative path
//    qDebug() << dbPath;

    // Create database connection
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbPath);

    if (db.open()) {
        QString createRecord = "CREATE TABLE IF NOT EXISTS record ("
                               "guid varchar(64) primary key, "
                               "state varchar(10), "
                               "institutionCode  varchar(20), "
                               "institutionName  varchar(50), "
                               "TotalAssets int(13), "
                               "MaxAccount int(13), "
                               "ControlClass varchar(10), "
                               "dataEntryClerk varchar(10), "
                               "inputTime DATETIME"
                               ")";
        QSqlQuery createQuery;
        if (createQuery.exec(createRecord)) {
            QString institutionCode[] = {"000030", "000031", "000032", "000033", "000034", "000035", "000036", "000037", "000038", "000039",
                                         "000040", "000041", "000042", "000043", "000044", "000045", "000046", "000047", "000048", "000049",
                                         "000050", "000051", "000052", "000053", "000054", "000055", "000056", "000057", "000058", "000059"};

            QString institutionName[] = {"金谷证券", "华通证券", "利丰证券", "和盈证券", "天涯证券", "同心证券", "久盛证券", "富达证券", "天翼证券", "融信证券",
                                        "金龙证券", "启迪证券", "信达证券", "银泰证券", "融通证券", "永盛证券", "华兴证券", "智诚证券", "兴业证券", "和信证券",
                                        "金鑫证券", "宏远证券", "世纪证券", "中正证券", "南风证券", "鸿业证券", "恒大证券", "嘉信证券", "国都证券", "长安证券"};

            QString TotalAssets[] = {"827", "463", "521", "287", "655", "974", "361", "119", "712", "593", "426", "875", "238",
                                    "582", "153", "951", "306", "672", "817", "566", "478", "695", "218", "432", "529", "747",
                                    "653", "394", "909", "179"};

            QString MaxAccount[] = {"827", "463", "521", "287", "655", "974", "361", "119", "712", "593", "426", "875", "238",
                                    "582", "153", "951", "306", "672", "817", "566", "478", "695", "218", "432", "529", "747",
                                    "653", "394", "909", "179"};

            int totalAssetsSize = sizeof(TotalAssets) / sizeof(TotalAssets[0]);
            int maxAccountSize = sizeof(MaxAccount) / sizeof(MaxAccount[0]);

            for (int i = 0; i < totalAssetsSize; i++) {
                TotalAssets[i] = QString::number(TotalAssets[i].toInt());
            }

            for (int i = 0; i < maxAccountSize; i++) {
                MaxAccount[i] = QString::number(MaxAccount[i].toInt());
            }

            QString ControlClass[] = {"机构业务类类", "会员资管类", "机构业务类", "会员资管类", "会员资管类", "会员资管类", "机构业务类", "会员资管类", "机构业务类",
                                    "机构业务类", "会员资管类", "会员资管类", "机构业务类", "机构业务类", "会员资管类", "会员资管类", "机构业务类", "机构业务类",
                                    "会员资管类", "会员资管类","会员资管类", "机构业务类", "机构业务类","机构业务类", "会员资管类", "机构业务类", "会员资管类", "机构业务类", "机构业务类","会员资管类"};

            QString dataEntryClerk[] = {"王佳", "李明", "刘婷婷", "赵伟", "陈超", "张琳", "杨晓", "周芳", "吴鑫", "朱雪", "梁娜", "何旭", "徐凯",
                                    "孙露", "马杰", "胡慧", "郭强", "林娟", "潘俊", "谢瑞", "罗梅", "郑飞", "钟娜", "彭洋", "邓磊", "陆晨", "金丽丽",
                                    "魏亮", "蒋萍", "夏鹏"};

            for (int i = 0; i < 30; i++) {
                QString insertUserData = "INSERT INTO record (guid, state, institutionCode, institutionName, TotalAssets, MaxAccount, ControlClass, dataEntryClerk, inputTime) VALUES "
                                         "('" + QString::number(i) + "', '已录入', '" + institutionCode[i] + "', '" + institutionName[i] + "', '" + TotalAssets[i] + "', '" + MaxAccount[i] +
                                         "', '" + ControlClass[i] + "', '" + dataEntryClerk[i] + "', '')";

                QSqlQuery insertQuery;
                if (!insertQuery.exec(insertUserData)) {
                    qDebug() << "Error executing query: " << insertQuery.lastError().text();
                }
            }
        } else {
            qDebug() << "Error creating table: " << createQuery.lastError().text();
        }
    }
}
