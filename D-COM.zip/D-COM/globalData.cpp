// GlobalData.cpp
#include "GlobalData.h"

QString globalUserName;
QString globalCusNumber;
