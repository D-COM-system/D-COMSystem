#include "RTGSEntryQuery.h"
#include "ui_RTGSEntryQuery.h"

#include <QWidget>
#include <QTableWidget>
#include <QHeaderView>
#include <QCheckBox>
#include <QHBoxLayout>
#include <QDebug>

RTGSEntryQuery::RTGSEntryQuery(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::RTGSEntryQuery),
    currentPage(0),
    pageSize(50),
    totalRows(10),
    totalPages((totalRows + pageSize - 1) / pageSize)
{
    ui->setupUi(this);
    QStringList headerLabels;
    headerLabels << "勾选" << "划付序号" << "处理状态" << "清算业务流水号" << "业务流水号"
                 << "结算账户" << "执行编号" << "备付金账户" << "清算业务类别"
                 << "证券代码" << "证券账户";
    ui->tableWidget_2->clear(); // 清空表格内容
    ui->tableWidget_2->setColumnCount(headerLabels.size());
    ui->tableWidget_2->setHorizontalHeaderLabels(headerLabels);
    ui->tableWidget_2->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget_2->setRowCount(pageSize);

    updateTableDisplay();
    qDebug() << totalRows;
    boolArray.resize(totalRows);
    for (int i = 0; i < totalRows; ++i)
    {
        boolArray[i] = false; // 默认赋值为 false
    }
    // 隐藏左侧的行号框
    ui->tableWidget_2->verticalHeader()->setVisible(false);
    connect(ui->pushButton_9, &QPushButton::clicked, this, &RTGSEntryQuery::previousPageButton_clicked);
    connect(ui->pushButton_10, &QPushButton::clicked, this, &RTGSEntryQuery::nextPageButton_clicked);
}

RTGSEntryQuery::~RTGSEntryQuery()
{
    delete ui;
}

void RTGSEntryQuery::selectRows()
{
    for (int var = 0; var < pageSize; var++) {
        int row = var + (currentPage * pageSize); // 计算当前页面的实际行索引
        if (row < totalRows) {
            QCheckBox* checkBox = qobject_cast<QCheckBox*>(ui->tableWidget_2->cellWidget(var, 0));
            if (checkBox) {
                boolArray[row] = checkBox->isChecked();
                checkboxStateMap[row] = checkBox->isChecked();
            }
        }
    }
}

void RTGSEntryQuery::checkbox_toggled(bool checked)
{
    for (int rowIndex = 0; rowIndex < pageSize; ++rowIndex) {
        int row = rowIndex + (currentPage * pageSize); // 计算当前页面的实际行索引
        if (row < totalRows) {
            QCheckBox* checkBox = qobject_cast<QCheckBox*>(ui->tableWidget_2->cellWidget(rowIndex, 0));
            if (checkBox) {
                checkBox->setChecked(checked);
                checkboxStateMap[row] = checked;
            }
        }
    }
}

void RTGSEntryQuery::updateTableDisplay()
{
    int startRow = currentPage * pageSize; // 当前页的起始行
    int endRow = qMin(startRow + pageSize, totalRows); // 当前页的结束行
    int numRows = endRow - startRow; // 当前页的行数
    ui->tableWidget_2->setRowCount(endRow - startRow);

    for (int row = startRow; row < endRow; ++row) {
        int rowIndex = row - startRow; // 当前页内的行索引

        QCheckBox *checkBox = new QCheckBox();
        ui->tableWidget_2->setCellWidget(rowIndex, 0, checkBox);
        connect(checkBox, &QCheckBox::clicked, this, &RTGSEntryQuery::selectRows);
        connect(ui->checkBox, &QCheckBox::toggled, this, &RTGSEntryQuery::checkbox_toggled);
        QTableWidgetItem *item1 = new QTableWidgetItem(QString::number(row));
        QTableWidgetItem *item2 = new QTableWidgetItem("处理中");
        QTableWidgetItem *item3 = new QTableWidgetItem("流水号" + QString::number(row));

        ui->tableWidget_2->setItem(rowIndex, 1, item1);
        ui->tableWidget_2->setItem(rowIndex, 2, item2);
        ui->tableWidget_2->setItem(rowIndex, 3, item3);

        // 根据checkboxStateMap设置勾选状态
        if (checkboxStateMap.contains(row) && checkboxStateMap[row]) {
            checkBox->setChecked(true);
        } else {
            checkBox->setChecked(false);
        }
    }
    ui->lineEdit_6->setText("当前页记录数:" + QString::number(numRows));
    ui->lineEdit_10->setText("当前页码:" + QString::number(currentPage + 1) + "/" + QString::number(totalPages));
    ui->lineEdit_11->setText("共计:" + QString::number(totalRows) + "条记录");
}


void RTGSEntryQuery::previousPageButton_clicked()
{
    if (currentPage > 0) {
        currentPage--;
        updateTableDisplay();
    }
}

void RTGSEntryQuery::nextPageButton_clicked()
{
    if (currentPage < totalPages - 1) {
        currentPage++;
        updateTableDisplay();
    }
}
