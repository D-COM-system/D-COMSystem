#include "FundBalanceQuery.h"
#include "ui_FundBalanceQuery.h"

FundBalanceQuery::FundBalanceQuery(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FundBalanceQuery)
{
    ui->setupUi(this);
}

FundBalanceQuery::~FundBalanceQuery()
{
    delete ui;
}
